package com.wav;

import jwave.datatypes.natives.Complex;

public class lowpass {
    }